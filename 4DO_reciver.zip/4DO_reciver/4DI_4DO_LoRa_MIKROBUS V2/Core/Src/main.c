/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdbool.h>
#include "sx1276_7_8.h"
#include "4DI_4DO_LoRa_MIKROBUS.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/*#define FREQ_CHANL_1      865062500
#define FREQ_CHANL_2      865232500
#define FREQ_CHANL_3      865402500
#define FREQ_CHANL_4      865785000
#define FREQ_CHANL_5      865985000
#define FREQ_CHANL_6      866185000
#define FREQ_CHANL_7      866385000
#define FREQ_CHANL_8      866585000
#define FREQ_CHANL_9      866785000
#define FREQ_CHANL_10      866985000 */


/*#define FREQ_CHANL_1  865062500
#define FREQ_CHANL_2  865212500
#define FREQ_CHANL_3  865362500
#define FREQ_CHANL_4  865512500
#define FREQ_CHANL_5  865662500
#define FREQ_CHANL_6  865812500
#define FREQ_CHANL_7  865962500
#define FREQ_CHANL_8  866112500
#define FREQ_CHANL_9  866262500
#define FREQ_CHANL_10 866412500
#define FREQ_CHANL_11 866562500
#define FREQ_CHANL_12 866712500
#define FREQ_CHANL_13 866862500  */


#define FREQ_CHANL_1  865000000
#define FREQ_CHANL_2  865133333
#define FREQ_CHANL_3  865266666
#define FREQ_CHANL_4  865400000
#define FREQ_CHANL_5  865533333
#define FREQ_CHANL_6  865666666
#define FREQ_CHANL_7  865800000
#define FREQ_CHANL_8  865933333
#define FREQ_CHANL_9  866066666
#define FREQ_CHANL_10 866200000
#define FREQ_CHANL_11 866333333
#define FREQ_CHANL_12 866466666
#define FREQ_CHANL_13 866600000
#define FREQ_CHANL_14 866733333
#define FREQ_CHANL_15 866866666
#define FREQ_CHANL_16 867000000






/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CRC_HandleTypeDef hcrc;

IWDG_HandleTypeDef hiwdg;

SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim6;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI2_Init(void);
static void MX_TIM3_Init(void);
static void MX_CRC_Init(void);
static void MX_TIM6_Init(void);
static void MX_IWDG_Init(void);
/* USER CODE BEGIN PFP */
// ##
uint8_t dipSwitchStatus(void);
void set_lora_param(uint8_t parameter_byte);
void generate_output(uint8_t data_from_Lora);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/*******************global variables************************/
uint8_t bandwidth;
uint8_t channel;
uint8_t spreadingFactor;
uint8_t txPower;
uint16_t SysTime = 0;

/******************** Rx parameter ************************/
uint8_t RxData[6];
uint8_t extractedData;
uint8_t lastExtractedData=0xFF;
uint16_t crcErrorCount = 0;


/******************** Device parameter ********************/
uint8_t deviceID;
uint8_t dip;


/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_SPI2_Init();
	MX_TIM3_Init();
	MX_CRC_Init();
	MX_TIM6_Init();
	MX_IWDG_Init();
	
	/* USER CODE BEGIN 2 */
	/* refreshing watch dog --> first*/
	// ##
	HAL_IWDG_Refresh(&hiwdg);
	dip = dipSwitchStatus();                            //read the dip switch
	set_lora_param(dip);                                // =LoRa parameter configuration

	/* Start 3 second timer6 */
	HAL_TIM_Base_Start(&htim6);
	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	// ##
	

	while(1)							//set in Receiver mode
	{
		HAL_IWDG_Refresh(&hiwdg); 
		
		if(sx1276_7_8_LoRaRxPacket(RxData,6))
		{
			/* refreshing watch dog */
			HAL_IWDG_Refresh(&hiwdg);
			extractedData = packetExtractor(RxData,deviceID,6);

			if(lastExtractedData!=extractedData)       //checks the previous data(if the are equal the not give the outpt signal)
			{
				generateOutput(extractedData);           //gives the output based on corresponding digital input
				lastExtractedData=extractedData;        //rupdating the lastExtractedData variable with the new data
			}
			__HAL_TIM_SET_COUNTER(&htim6, 0x00);				//Reseting counter, if data Received 

		}


		/* Condition to wait for received data till 30 Sec, if packet not received RESET output */
		if(__HAL_TIM_GET_COUNTER(&htim6) >  10000)
		{
			HAL_IWDG_Refresh(&hiwdg); //new
			extractedData = 0x00;
			generateOutput(extractedData);
			lastExtractedData=extractedData;			
			__HAL_TIM_SET_COUNTER(&htim6, 0x00);				//Reseting counter, if data Received 
		}
	}
}
/* USER CODE END 3 */


/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = {0};
	RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.LSIState = RCC_LSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL8;
	RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	*/
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
		|RCC_CLOCKTYPE_PCLK1;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
	{
		Error_Handler();
	}
}

/**
 * @brief CRC Initialization Function
 * @param None
 * @retval None
 */
static void MX_CRC_Init(void)
{

	/* USER CODE BEGIN CRC_Init 0 */

	/* USER CODE END CRC_Init 0 */

	/* USER CODE BEGIN CRC_Init 1 */

	/* USER CODE END CRC_Init 1 */
	hcrc.Instance = CRC;
	hcrc.Init.DefaultInitValueUse = DEFAULT_INIT_VALUE_ENABLE;
	hcrc.Init.InputDataInversionMode = CRC_INPUTDATA_INVERSION_NONE;
	hcrc.Init.OutputDataInversionMode = CRC_OUTPUTDATA_INVERSION_DISABLE;
	hcrc.InputDataFormat = CRC_INPUTDATA_FORMAT_BYTES;
	if (HAL_CRC_Init(&hcrc) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN CRC_Init 2 */

	/* USER CODE END CRC_Init 2 */

}

/**
 * @brief IWDG Initialization Function
 * @param None
 * @retval None
 */
static void MX_IWDG_Init(void)
{

	/* USER CODE BEGIN IWDG_Init 0 */

	/* USER CODE END IWDG_Init 0 */

	/* USER CODE BEGIN IWDG_Init 1 */

	/* USER CODE END IWDG_Init 1 */
	hiwdg.Instance = IWDG;
	hiwdg.Init.Prescaler = IWDG_PRESCALER_64;
	hiwdg.Init.Window = 4095;
	hiwdg.Init.Reload = 4095;
	if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN IWDG_Init 2 */

	/* USER CODE END IWDG_Init 2 */

}

/**
 * @brief SPI2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_SPI2_Init(void)
{

	/* USER CODE BEGIN SPI2_Init 0 */

	/* USER CODE END SPI2_Init 0 */

	/* USER CODE BEGIN SPI2_Init 1 */

	/* USER CODE END SPI2_Init 1 */
	/* SPI2 parameter configuration*/
	hspi2.Instance = SPI2;
	hspi2.Init.Mode = SPI_MODE_MASTER;
	hspi2.Init.Direction = SPI_DIRECTION_2LINES;
	hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
	hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
	hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
	hspi2.Init.NSS = SPI_NSS_SOFT;
	hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
	hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
	hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
	hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	hspi2.Init.CRCPolynomial = 7;
	hspi2.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
	hspi2.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
	if (HAL_SPI_Init(&hspi2) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN SPI2_Init 2 */

	/* USER CODE END SPI2_Init 2 */

}

/**
 * @brief TIM3 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM3_Init(void)
{

	/* USER CODE BEGIN TIM3_Init 0 */

	/* USER CODE END TIM3_Init 0 */

	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	/* USER CODE BEGIN TIM3_Init 1 */

	/* USER CODE END TIM3_Init 1 */
	htim3.Instance = TIM3;
	htim3.Init.Prescaler = 32000-1;
	htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim3.Init.Period = 65535;
	htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
	{
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM3_Init 2 */

	/* USER CODE END TIM3_Init 2 */

}

/**
 * @brief TIM6 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM6_Init(void)
{

	/* USER CODE BEGIN TIM6_Init 0 */

	/* USER CODE END TIM6_Init 0 */

	/* USER CODE BEGIN TIM6_Init 1 */

	/* USER CODE END TIM6_Init 1 */
	htim6.Instance = TIM6;
	htim6.Init.Prescaler = 32000-1;
	htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim6.Init.Period = 65535;
	htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM6_Init 2 */

	/* USER CODE END TIM6_Init 2 */

}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, DO_1_Pin|DO_2_Pin|DO_3_Pin|DO_4_Pin
			|LoRa_DIO_0_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, LED_Pin|LoRa_NSS_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pins : DIP_6_Pin DIP_7_Pin */
	GPIO_InitStruct.Pin = DIP_6_Pin|DIP_7_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/*Configure GPIO pins : DO_1_Pin DO_2_Pin DO_3_Pin DO_4_Pin
	  LoRa_DIO_0_Pin */
	GPIO_InitStruct.Pin = DO_1_Pin|DO_2_Pin|DO_3_Pin|DO_4_Pin
		|LoRa_DIO_0_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pins : DIP_3_Pin DIP_2_Pin DIP_1_Pin DIP_0_Pin
	  DI_2_Pin DI_3_Pin DI_4_Pin DIP_4_Pin
	  DIP_5_Pin */
	GPIO_InitStruct.Pin = DIP_3_Pin|DIP_2_Pin|DIP_1_Pin|DIP_0_Pin
		|DI_2_Pin|DI_3_Pin|DI_4_Pin|DIP_4_Pin
		|DIP_5_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/*Configure GPIO pins : LED_Pin LoRa_NSS_Pin */
	GPIO_InitStruct.Pin = LED_Pin|LoRa_NSS_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/*Configure GPIO pin : DI_1_Pin */
	GPIO_InitStruct.Pin = DI_1_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(DI_1_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
uint8_t dipSwitchStatus()
{
	bool dipTemp[8] = {0};
	uint8_t dipTempByte = 0;

	if(HAL_GPIO_ReadPin(DIP_0_GPIO_Port,DIP_0_Pin)==GPIO_PIN_SET)	{dipTemp[0]=0;}
	else	{dipTemp[0]=1;}

	if(HAL_GPIO_ReadPin(DIP_1_GPIO_Port,DIP_1_Pin)==GPIO_PIN_SET)	{dipTemp[1]=0;}
	else	{dipTemp[1]=1;}

	if(HAL_GPIO_ReadPin(DIP_2_GPIO_Port,DIP_2_Pin)==GPIO_PIN_SET)	{dipTemp[2]=0;}
	else	{dipTemp[2]=1;}

	if(HAL_GPIO_ReadPin(DIP_3_GPIO_Port,DIP_3_Pin)==GPIO_PIN_SET)	{dipTemp[3]=0;}
	else	{dipTemp[3]=1;}

	if(HAL_GPIO_ReadPin(DIP_4_GPIO_Port,DIP_4_Pin)==GPIO_PIN_SET)	{dipTemp[4]=0;}
	else	{dipTemp[4]=1;}

	if(HAL_GPIO_ReadPin(DIP_5_GPIO_Port,DIP_5_Pin)==GPIO_PIN_SET)	{dipTemp[5]=0;}
	else	{dipTemp[5]=1;}

	if(HAL_GPIO_ReadPin(DIP_6_GPIO_Port,DIP_6_Pin)==GPIO_PIN_SET)	{dipTemp[6]=0;}
	else	{dipTemp[6]=1;}
	
	if(HAL_GPIO_ReadPin(DIP_7_GPIO_Port,DIP_7_Pin)==GPIO_PIN_SET)	{dipTemp[7]=0;}
	else	{dipTemp[7]=1;}

	dipTempByte=  dipTemp[7]<<7 | dipTemp[6]<<6 | dipTemp[5]<<5 | dipTemp[4]<<4 | dipTemp[3]<<3 | dipTemp[2]<<2 | dipTemp[1]<<1 | dipTemp[0];

	return dipTempByte;
}

/**
 * @brief To set the lora parameters according to DIP Switch
 * @name  set_lora_param
 * @param parameter_byte
 * @retval None
 */
void set_lora_param(uint8_t parameter_byte)
{

	/*	Transmitter power	*/
	//txPower = 0x00;

	/*  Bandwidth		*/
	/*	0				1					2					3					4					5					6					7				8				9				*/	
	/*	7.8KHz,	10.4KHz,	15.6KHz,	20.8KHz,	31.2KHz,	41.7KHz,	62.5KHz,	125KHz,	250KHz,	500KHz	*/
	bandwidth = 6;

	/*	spreadingFactor	*/
	/*	0					1					2					3					4					5					6			*/	
	/*	SF=6			SF=7			SF=8			SF=9			SF=10			SF=11			SF=12	*/

	spreadingFactor = ((parameter_byte)& 0x03) + 0x03; // bit 0,1

	channel=(parameter_byte>>2)& 0x0F; // bit 2,3,4,5 --> new

	/*	Transmitter ID	*/
	deviceID=(parameter_byte>>6) & 0x01;  // --> new
	
	txPower =(parameter_byte>>7);

	//	/*	Transmitter Device Type (8DI OR 12DI)	*/
	//	txDeviceType=(parameter_byte>>5)&0x07;
	// ## txDeviceType=(parameter_byte>>6)&0x03;			//bit 6 & 7 used for device type
	/*	Receiver Output Selection	*/

	if(channel==0)
		set_frequency(FREQ_CHANL_1);             //set the frequency(FREQUENCY IS DEFINED AT THE TOP)
	else if(channel==1)
		set_frequency(FREQ_CHANL_2);             //set the frequency(FREQUENCY IS DEFINED AT THE TOP)
	else if(channel==2)
		set_frequency(FREQ_CHANL_3);             //set the frequency(FREQUENCY IS DEFINED AT THE TOP)
	else if(channel==3)
		set_frequency(FREQ_CHANL_4);             //set the frequency(FREQUENCY IS DEFINED AT THE TOP)
	else if(channel==4)
		set_frequency(FREQ_CHANL_5);             //set the frequency(FREQUENCY IS DEFINED AT THE TOP)
	else if(channel==5)
		set_frequency(FREQ_CHANL_6);             //set the frequency(FREQUENCY IS DEFINED AT THE TOP)
	else if(channel==6)
		set_frequency(FREQ_CHANL_7);             //set the frequency(FREQUENCY IS DEFINED AT THE TOP)
	else if(channel==7)
		set_frequency(FREQ_CHANL_8);             //set the frequency(FREQUENCY IS DEFINED AT THE TOP)
	else if(channel==8)
		set_frequency(FREQ_CHANL_9);             //set the frequency(FREQUENCY IS DEFINED AT THE TOP)
	else if(channel==9)
		set_frequency(FREQ_CHANL_10);             //set the frequency(FREQUENCY IS DEFINED AT THE TOP)
	
	
	
	else if(channel==10)
		set_frequency(FREQ_CHANL_11); 
else if(channel==11)
		set_frequency(FREQ_CHANL_12); 
else if(channel==12)
		set_frequency(FREQ_CHANL_13); 

else if(channel==13)
		set_frequency(FREQ_CHANL_14); 
else if(channel==14)
		set_frequency(FREQ_CHANL_15); 
else if(channel==15)
		set_frequency(FREQ_CHANL_16); 



	/*******************************************************************/

	sx1276_7_8_Config(txPower,bandwidth,spreadingFactor);                                //configure the rfm95
	sx1276_7_8_LoRaEntryRx(txPower, bandwidth, spreadingFactor);                           //LoRa in receive mode

}


/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
