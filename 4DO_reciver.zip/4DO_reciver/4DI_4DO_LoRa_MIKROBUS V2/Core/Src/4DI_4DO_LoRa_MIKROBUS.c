/**
  ******************************************************************************
  * @file           : 8do_board.c
  * @brief          : 8 DO Board Library for STM32
  * @Date           : 01 DEC 2019
  ******************************************************************************
  * Copyright (c) 2019 Suman Kumar Das <sumancvb@gmail.com>
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without
  * modification, are permitted provided that the following conditions
  * are met:
  * 1. Redistributions of source code must retain the above copyright
  *    notice, this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright
  *    notice, this list of conditions and the following disclaimer in the
  *    documentation and/or other materials provided with the distribution.
  * 3. The name of the author may not be used to endorse or promote products
  *    derived from this software without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
  * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
  * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
  * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
  * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
  * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

#include "main.h"
#include "4DI_4DO_LoRa_MIKROBUS.h"


//bool di_temp[16] ={0};
/**
  * @brief  Generate the Digital Outputs
  * @name   generateOutput
  * @param  bool *output_data
  * @retval None
  */
void generateOutput(uint8_t output_data)
{
	if			(((output_data >> 3)  & 0x0001) == 0x0001)	{HAL_GPIO_WritePin(DO_4_GPIO_Port,DO_4_Pin,GPIO_PIN_SET);	}
	else if		((( output_data >> 3) & 0x0001) == 0x0000)	{HAL_GPIO_WritePin(DO_4_GPIO_Port,DO_4_Pin,GPIO_PIN_RESET);}
	
	if			(((output_data >> 2) & 0x0001) == 0x0001)	{HAL_GPIO_WritePin(DO_3_GPIO_Port,DO_3_Pin,GPIO_PIN_SET);	}
	else if		(((output_data >> 2) & 0x0001) == 0x0000)	{HAL_GPIO_WritePin(DO_3_GPIO_Port,DO_3_Pin,GPIO_PIN_RESET);}
	
	if			(((output_data >> 1 & 0x0001)) == 0x0001)	{HAL_GPIO_WritePin(DO_2_GPIO_Port,DO_2_Pin,GPIO_PIN_SET);	}
	else if		(((output_data >> 1) & 0x0001) == 0x0000)	{HAL_GPIO_WritePin(DO_2_GPIO_Port,DO_2_Pin,GPIO_PIN_RESET);}
	
	if			((output_data & 0x0001) == 0x0001)	{HAL_GPIO_WritePin(DO_1_GPIO_Port,DO_1_Pin,GPIO_PIN_SET);	}
	else if		((output_data & 0x0001) == 0x0000)	{HAL_GPIO_WritePin(DO_1_GPIO_Port,DO_1_Pin,GPIO_PIN_RESET);}
}


/**
  * @brief To get the digital inputs from MCU and return the value of all the digital inputs
  * @name  get_di_data
  * @param None
  * @retval di_data
  */
void get_di_data(uint8_t* value)
{
//	memset(di_temp,0,16);
	bool di_temp[16] ={0};
//	di_temp = 0x00;
	if(HAL_GPIO_ReadPin(DI_1_GPIO_Port,DI_1_Pin)==GPIO_PIN_SET)	{di_temp[0]=0;}
	else	{di_temp[0]=1;}
		
	if(HAL_GPIO_ReadPin(DI_2_GPIO_Port,DI_2_Pin)==GPIO_PIN_SET)	{di_temp[1]=0;}
	else	{di_temp[1]=1;}
		
	if(HAL_GPIO_ReadPin(DI_3_GPIO_Port,DI_3_Pin)==GPIO_PIN_SET)	{di_temp[2]=0;}
	else	{di_temp[2]=1;}
		
	if(HAL_GPIO_ReadPin(DI_4_GPIO_Port,DI_4_Pin)==GPIO_PIN_SET)	{di_temp[3]=0;}
	else	{di_temp[3]=1;}

	value[0]= di_temp[3]<<3 | di_temp[2]<<2 | di_temp[1]<<1 | di_temp[0];
}


